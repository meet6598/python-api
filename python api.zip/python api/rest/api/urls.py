from django.urls import path
from .views import clientViews,projectViews
urlpatterns=[
    path('client/',clientViews.as_view()),
    path('project/',projectViews.as_view()),


]