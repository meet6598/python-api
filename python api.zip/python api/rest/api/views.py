from django.shortcuts import render
from rest_framework import generics
from .models import client,project

from .serializer import clientSerializer,projectSerializer


# Create your views here.
class clientViews(generics.ListCreateAPIView):
    queryset = client.objects.all()
    serializer_class = clientSerializer

class projectViews(generics.ListCreateAPIView):
    queryset = project.objects.all()
    serializer_class = projectSerializer


