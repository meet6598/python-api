from rest_framework import serializers
from .models import client,project

class clientSerializer(serializers.ModelSerializer):
    name=serializers.CharField(max_length=200)



    class Meta:
        model = client
        fields = ('__all__')



class projectSerializer(serializers.ModelSerializer):
    name=serializers.CharField(max_length=200)


    class Meta:
        model = project
        fields = ('__all__')