from django.contrib import admin
from .models import client,project
# Register your models here.
admin.site.register(client)
admin.site.register(project)